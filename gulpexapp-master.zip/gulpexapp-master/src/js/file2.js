// Console Log

console.log('This is file 2');

// Alert

alert('This is file 2');
